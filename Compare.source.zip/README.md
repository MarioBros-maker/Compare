# Compare-比较程序
A program written in Visual Basic.-一个用VB语言编写的程序
